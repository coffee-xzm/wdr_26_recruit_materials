#include<bits/stdc++.h>
using namespace std;
//ax2+bx+c 
float a,b,c;
float delta;
float x1,x2;

void zero(){
	cout<<"�������û��ʵ��"<<endl;
	return;
} 
void one(){
	float x = (-b)/(2*a);
	cout<<x<<endl;
	return;
}
void two(){
	float sq = sqrt(delta);
	float x1 = (-b+sq)/(2*a);
	float x2 = (-b-sq)/(2*a);
	cout<<x1<<" "<<x2<<endl;
	return;
}
void judge(float delta){
	if(delta<0)return zero();
	else if(delta ==0)return one();
	else if(delta >0)return two();
}
int main(){
	cin>>a>>b>>c;
	delta =(b*b)-4*a*c;
	judge(delta);
	return 0;
}

