#include<bits/stdc++.h>
using namespace std;
const int N=1005;
int n,maxm= -1;
struct Student{
	char name[25];
	int num;
	int grade;
	
}ss[N];
void printStudent(const Student& s){
	cout<<"����:"<<s.name<<"ѧ��:"<<s.num<<"�ɼ���"<<s.grade<<endl; 
	return;
}
//Student& s[N]=ss[N];
Student* findTopStudent(Student arr[],int n){
	Student* p =&arr[0];
	
	for(int i=0;i<n;i++){
		if(arr[i].grade>p->grade){
			p =&arr[i];
		}
	}
	return p;
}

int main(){
	cin>>n;
	for(int i=0;i<n;i++)cin>>ss[i].name>>ss[i].num>>ss[i].grade;
	Student* pp = findTopStudent(ss,n);
	printStudent(*pp);
	
	return 0;
}

