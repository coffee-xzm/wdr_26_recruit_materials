#include <iostream>
#include <vector>

using namespace std;

int main() {
    vector<string> fruits;

    // 1. 增加元素（push_back在末尾添加）
    fruits.push_back("apple");
    fruits.push_back("banana");
    fruits.push_back("cherry");
    cout << "添加后：";
    for (auto f : fruits) {
        cout << f << " ";
    }
    cout << endl;

    // 2. 修改元素（下标或迭代器）
    fruits[1] = "blueberry"; // 修改下标1的元素
    cout << "修改后：";
    for (auto f : fruits) {
        cout << f << " ";
    }
    cout << endl;

    // 3. 插入元素（在指定位置插入）
    fruits.insert(fruits.begin() + 1, "orange"); // 在第2个位置插入
    cout << "插入后：";
    for (auto f : fruits) {
        cout << f << " ";
    }
    cout << endl;

    // 4. 删除元素（删除指定位置）
    fruits.erase(fruits.end() - 1); // 删除最后一个元素
    cout << "删除后：";
    for (auto f : fruits) {
        cout << f << " ";
    }
    cout << endl;

    // 5. 清空与判断空
    fruits.clear();
    if (fruits.empty()) {
        cout << "已清空，vector为空" << endl;
    }

    return 0;
}