#include <iostream>
#include <vector> // 包含vector头文件

using namespace std;

int main() {
    // 1. 初始化方式
    vector<int> v1; // 空vector
    vector<int> v2(3); // 初始化3个元素，默认值为0
    vector<int> v3(4, 10); // 初始化4个元素，每个值为10
    vector<int> v4 = {1, 2, 3, 4, 5}; // 列表初始化（C++11及以上）
    vector<int> v5(v4.begin(), v4.end()); // 用v4的迭代器范围初始化

    // 2. 遍历方式1：下标访问（类似数组）
    cout << "v4的元素（下标访问）：";
    for (int i = 0; i < v4.size(); ++i) {
        cout << v4[i] << " ";
    }
    cout << endl;

    // 3. 遍历方式2：迭代器（更通用，支持所有容器）
    cout << "v5的元素（迭代器访问）：";
    for (vector<int>::iterator it = v5.begin(); it != v5.end(); ++it) {
        cout << *it << " "; // 迭代器解引用获取元素
    }
    cout << endl;

    // 4. 遍历方式3：范围for循环（C++11及以上，简洁）
    cout << "v3的元素（范围for）：";
    for (int num : v3) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}