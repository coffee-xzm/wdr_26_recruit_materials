#pragma once
#include <iostream>
using namespace std;
//在头文件里写类与函数的声明

//语法：class 类名 {访问权修饰符 成员变量/成员函数}
class Student {
public:
    //无参构造函数
    Student();
    
    //有参构造函数
    Student(string name, int age);

    //拷贝构造函数
    Student(Student &student);

    //析构函数
    ~Student();

    //成员函数
    void show();

//私有成员变量
private:
    //学生姓名
    string name;
    //学生年龄
    int age;
};