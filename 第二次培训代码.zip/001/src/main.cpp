#include "include/student.hpp"

int main()
{
    Student s("Tom", 18);
    s.show();

    return 0;
}
