#include "include/student.hpp"

//在源文件里写类与函数的实现
//无参构造函数
Student::Student()
{
    cout << "无参构造函数的调用" << endl;
}

//有参构造函数，使用初始化列表
Student::Student(string name, int age) : name(name), age(age)
{
    cout << "有参构造函数的调用" << endl;
}

//拷贝构造函数
Student::Student(Student &student)
{
    cout << "拷贝构造函数的调用" << endl;
    this->name = student.name;
    this->age = student.age;
}

//析构函数
Student::~Student()
{
    cout << "析构函数的调用" << endl;
}

//成员函数
void Student::show()
{
    cout << "姓名：" << this->name << "，年龄：" << this->age << endl;
}