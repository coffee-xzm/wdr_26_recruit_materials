#include <iostream>
#include <string>
using namespace std;

// 基类 Fruit
class Fruit {
//1.protected关键字的作用?
protected:    
    string type;
    string color;
    string flavor; 
public:
    Fruit(string t, string c, string f) : type(t), color(c), flavor(f) {} 
    void info(){    // 公有成员方法
        cout <<"Fruit func: I'm " << type << endl;
    }
    void get_type() { 
        cout << "Fruit"<<endl;
    }

//2.以下两个成员方法中，virtual代表什么含义?
    virtual void get_color() { 
        cout << "Fruit color is " << color << endl;
    }
    virtual void get_flavor() = 0; 
//3.这两种virtual function有什么区别?
};

// 继承类 Apple
class Apple : public Fruit {
//4.这里为什么使用private，而不是同于基类中的protected?
//  不改变其他代码的情况下，基类中的两个成员变量改为private可以吗?
    private:
    string origin; //产地

public:
    Apple(string t, string c, string f, string o) : Fruit(t, c, f), origin(o) {}
    
    void get_origin() {
        cout << "Origin: " << origin << endl;
    }
//重写了三个基类中的成员方法
    void get_type() {
        cout << "Apple"<<endl;
    }
//5.override关键字什么意思？可否去掉？
    void get_color() override{
        cout << "Apple color is " << color << endl;
    }
    void get_flavor() override {
        cout << "Apple flavor is " << flavor << endl;
    }

};

int main() {
    // 创建Fruit和Apple对象

//6.以下这一行能否正常运行不报错？
    // Fruit fruit1("fruit","yellow","sweet");

    Apple apple1("apple1", "red", "sweet", "China");
    Apple apple2("apple2", "yellow", "sour", "America");
    Fruit* fruit = &apple2;
    
    // 调用成员方法
//7.->与.的区别？
    cout<<"-----------基类的成员方法: info()----------"<<endl;
    apple1.info();
    apple2.info();
    fruit->info();
    cout<<endl;

    cout<<"-----------未使用virtual标识, 在继承类中被重写: get_type()----------"<<endl;
    apple1.get_type();
    apple2.get_type();
    fruit->get_type();
    cout<<endl;

    cout<<"-----------在继承类中被重写的virtual func: get_color()----------"<<endl;
    apple1.get_color();
    apple2.get_color();
    fruit->get_color();
    cout<<endl;

    cout<<"-----------基类中无实现的virtual func: get_flavor()----------"<<endl;
    apple1.get_flavor();
    apple2.get_flavor();
    fruit->get_flavor();
    cout<<endl;
  
    cout<<"-----------继承类中新声明的成员方法: get_origin()----------"<<endl;  
    apple1.get_origin();
    apple2.get_origin();

// 8.以下这行能否放开注释不报错？
    // fruit->get_origin();
    cout << endl;
    return 0;
}