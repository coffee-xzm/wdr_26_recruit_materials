#pragma once
#include <iostream>
using namespace std;

class Animal
{
public:
    virtual void speak()
    {
        cout << "动物叫" << endl;
    }

    void ChangeName(string name)
    {
        this->name = name;
    }

    string getName()
    {
        return this->name;
    }

private:
    string name;
};

class Dog : public Animal
{
public:
    void speak() override
    {
        ChangeName("狗");
        cout << getName() << "汪汪汪" << endl;
    }

};

class Cat : public Animal
{
public:
    void speak() override
    {
        ChangeName("猫");
        cout << getName() << "哈哈哈" << endl;
    }

};
