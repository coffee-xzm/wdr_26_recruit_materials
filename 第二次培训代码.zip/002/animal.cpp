#include "animal.hpp"

void Demo(Animal*a)
{
    a->speak();
}

int main()
{
    Dog *dog = new Dog();
    Cat *cat = new Cat();

    Demo(dog);
    Demo(cat);

    return 0;
}