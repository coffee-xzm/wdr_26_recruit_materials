#include <iostream>
#include <string>

using namespace std;

// 1. 函数模板：交换两个值
template <typename T>
void swapVal(T& a, T& b) {
    T temp = a;
    a = b;
    b = temp;
}

// 2. 类模板：简单容器（存一个元素）
template <typename T>
class Box {
private:
    T item;
public:
    Box(T x) : item(x) {}  // 构造函数
    T get() { return item; }  // 获取元素
    void set(T x) { item = x; }  // 修改元素
};

// 3. 函数模板特化：针对字符串比较
template <typename T>
bool isSame(T a, T b) {
    return a == b;
}
// 特化版本（处理字符串）
template <>
bool isSame<const char*>(const char* a, const char* b) {
    return string(a) == string(b);  // 字符串内容比较
}

int main() {
    // 测试函数模板swapVal
    int a = 10, b = 20;
    swapVal(a, b);
    cout << "交换后：a=" << a << ", b=" << b << endl;  // 20,10

    string s1 = "hi", s2 = "bye";
    swapVal(s1, s2);
    cout << "交换后：s1=" << s1 << ", s2=" << s2 << endl;  // bye,hi

    // 测试类模板Box
    Box<int> intBox(100);
    cout << "int盒子：" << intBox.get() << endl;  // 100

    Box<string> strBox("模板");
    cout << "string盒子：" << strBox.get() << endl;  // 模板

    // 测试特化函数isSame
    cout << "1和1是否相同？" << (isSame(1, 1) ? "是" : "否") << endl;  // 是
    cout << "\"abc\"和\"abc\"是否相同？" << (isSame("abc", "abc") ? "是" : "否") << endl;  // 是

    return 0;
}