#include <iostream>
using namespace std;

/*
C++的两种编程思想：面向对象编程、泛型编程
模板是泛型编程的基础
模板不可以直接使用，它只是一个框架
模板的通用不是万能的

C++提供两种模板机制：函数模板、类模板
*/

// 1.函数模板 -- 目的：提高函数的复用性、将类型参数化
// 建立一个通用函数，其返回值类型和参数类型可以不具体指定，用一个虚拟的类型来代替

template <typename T> // 声明一个模板，告诉编译器后面代码中的T是一个通用数据类型
    // template <class T> // 也可以使用class关键字，效果一样
    //template -- 声明创建模板， typename/class -- 表示其后的符号是一种数据类型，T -- 通用数据类型的名称，可以自定义
T myFunc(T a, T b) {
	return a > b ? a : b;
}
// 模板必须要确定出类型才能使用，举例如下：
template <typename T=double> 
void myFunc2() {
    cout<< "myFunc2调用" << endl;
}

int main() {
    //1.自动类型推导
    int a = 10;
    int b = 20;
    cout << "max(a, b) = " << myFunc(a, b) << endl; // 自动类型推导，T被推导为int类型

    double c = 1.1;
    double d = 2.2;
    cout << "max(c, d) = " << myFunc(c, d) << endl; // T被推导为double类型

    char e = 'a';
    char f = 'b';
    cout << "max(e, f) = " << myFunc(e, f) << endl;  // T被推导为char类型

    // cout << "max(a, c) = " << myFunc(a, c) << endl; // 错误，T无法推导出来 --> 自动类型推导时，必须推导出唯一的数据类型，模板才可以使用
    // 2. 显式指定类型
    cout << "max(a, c) = " << myFunc<double>(a, c) << endl; // T被指定为double类型, a会被隐式转换为double类型

    //模板必须要确定出类型（两种方法：指定默认参数类型/显式指定类型）才能使用，举例如下：
    // myFunc2<int>();
    myFunc2();

    return 0;
}   

//普通函数与函数模板
//1.如果函数模板和普通函数都可以实现，优先调用普通函数
//2.可以通过空模板参数列表，强制调用函数模板
//3.函数模板也可以发生函数重载
//4.如果函数模板可以产生更好的匹配，优先调用函数模板

/*函数是对对象的行为抽象，类是对对象的属性抽象
  函数模板是对函数的行为抽象，类模板是对类的属性抽象
*/
/*函数是对相似的程序段抽象，函数模板是对功能相似的函数抽象*/
