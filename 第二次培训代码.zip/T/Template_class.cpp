#include <iostream>
using namespace std;

// 2.类模板 -- 目的：提高类的复用性、将类型参数化
template <typename T1, typename T2 = double> // 可以有多个模板参数
class Person {
public:
    Person(T1 name, T2 age) {
        this->m_Name = name;
        this->m_Age = age;
    }
    void showPerson() {
        cout << "name: " << this->m_Name << ", age: " << this->m_Age << endl;
    }
public:     
    T1 m_Name;
    T2 m_Age;
};

int main() {
    std::cout << __cplusplus << std::endl;
    Person p("张三", 25); // 指定类型
    p.showPerson();

    Person<int, int> p2(1001, 30); // 指定类型
    p2.showPerson();

    return 0;
}

/*类是对具有相同属性的对象的抽象，类模板是对属性列表相似的类的抽象*/