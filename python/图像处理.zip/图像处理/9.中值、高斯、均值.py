import cv2

# 读取图像（支持彩色或灰度图，这里以彩色图为例）
img = cv2.imread("D:\\zhongzhi.png")  # 不指定参数则读取为BGR彩色图

# 1. 均值滤波（cv2.blur）
# 参数：(5,5)为滤波核大小（奇数，可调整）
mean_blur = cv2.blur(img, (5, 5))

# 2. 高斯滤波（cv2.GaussianBlur）
# 参数：(5,5)为核大小，sigmaX=1.0为X方向标准差（控制模糊程度）
gaussian_blur = cv2.GaussianBlur(img, (5, 5), sigmaX=1.0)

# 3. 中值滤波（cv2.medianBlur）
# 参数：5为核大小（奇数，仅需指定边长）
median_blur = cv2.medianBlur(img, 5)

# 创建窗口显示结果（使用cv2的imshow）
cv2.namedWindow("img", cv2.WINDOW_NORMAL)
cv2.namedWindow("junzhi", cv2.WINDOW_NORMAL)
cv2.namedWindow("gaosi", cv2.WINDOW_NORMAL)
cv2.namedWindow("zhongzhi", cv2.WINDOW_NORMAL)

# 显示图像
cv2.imshow("img", img)
cv2.imshow("junzhi", mean_blur)
cv2.imshow("gaosi", gaussian_blur)
cv2.imshow("zhongzhi", median_blur)

# 等待按键（0表示无限等待，按任意键退出）
cv2.waitKey(0)
# 关闭所有窗口
cv2.destroyAllWindows()