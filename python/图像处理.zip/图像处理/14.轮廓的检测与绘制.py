import cv2
import numpy as np
# 1. 读取图像并转为灰度图
img = cv2.imread('D://111.png')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# 2. 二值化处理（关键步骤：将图像转为黑白）
# 这里使用自适应阈值，也可使用固定阈值cv2.threshold()
ret,thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)  # 反转阈值（目标为白，背景为黑）

# 3. 检测轮廓
contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# 4. 绘制轮廓（在原图上用绿色线条绘制所有轮廓）
# 参数：图像、轮廓列表、轮廓索引（-1表示所有轮廓）、颜色、线宽
cv2.drawContours(img, contours, -1, (0, 255, 0), 2)
cv2.imshow('contours', img)
cv2.waitKey(0)
