import cv2
import numpy as np

# 读取原始图像（彩色）
img = cv2.imread("image.jpg")
h, w = img.shape[:2]  # 获取图像尺寸
# 创建掩膜（初始为全黑）
mask = np.zeros((h, w), np.uint8)
# 在掩膜中标记感兴趣区域（例如：中心100x100的矩形）
cv2.rectangle(mask, (w//2-50, h//2-50), (w//2+50, h//2+50), 255, -1)

# 应用掩膜：只保留掩膜中非0区域的像素
masked_img = cv2.bitwise_and(img, img, mask=mask)
# 显示结果
cv2.imshow("Original", img)
cv2.imshow("Mask", mask)
cv2.imshow("Masked Image", masked_img)
cv2.waitKey(0)
cv2.destroyAllWindows()
