import cv2 
import numpy as np

# 读取图像
img = cv2.imread('D://111.png')
rows, cols = img.shape[:2] 
# 获取图像行数（高度）和列数（宽度）

# 1. 定义平移矩阵
# (tx=100, ty=50 表示向右移100，向下移50)
tx, ty = 100, 50
M = np.float32([[1, 0, tx], [0, 1, ty]])
# 2. 应用仿射变换
# 参数：原始图像、变换矩阵、输出图像尺寸（cols, rows）
translated_img = cv2.warpAffine(img, M, (cols, rows))
# 显示结果
cv2.imshow('Original', img)
cv2.imshow('Translated', translated_img)
cv2.waitKey(0)
cv2.destroyAllWindows()



# import cv2 
# import numpy as np

# img = cv2.imread('image.jpg')
# rows, cols = img.shape[:2]

# # 1. 生成旋转矩阵（绕中心旋转45度，不缩放）
# center = (cols/2, rows/2)  # 旋转中心
# angle = 45  # 旋转角度（逆时针）
# scale = 1   # 缩放比例
# M = cv2.getRotationMatrix2D(center, angle, scale)

# # 2. 应用仿射变换（注意：旋转后可能超出原图范围，可保持原尺寸或计算新尺寸）
# rotated_img = cv2.warpAffine(img, M, (cols, rows))

# # 显示结果
# cv2.imshow('Original', img)
# cv2.imshow('Rotated', rotated_img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
