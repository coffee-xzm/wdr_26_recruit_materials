import cv2

# ----------------------
# 1. 读取并显示本地视频文件
# ----------------------
# 读取本地视频（替换为实际路径）
cap_video = cv2.VideoCapture("video.mp4")

# 判断视频是否成功打开
if not cap_video.isOpened():
    print("无法打开视频文件，请检查路径是否正确")
else:
    while True:
        # 读取一帧
        ret, frame = cap_video.read()
        if not ret:  # 视频结束或读取失败
            print("视频播放结束")
            break
        # 显示当前帧
        cv2.imshow("Video Player", frame)
        # 等待1ms，按'q'键退出
        if cv2.waitKey(1) == ord('q'):
            print("用户退出视频播放")
            break
    # 释放视频资源
    cap_video.release()
    cv2.destroyAllWindows()  # 关闭视频显示窗口


# ----------------------
# 2. 调用摄像头并录制视频
# ----------------------
# 打开默认摄像头（0为默认摄像头）
cap_cam = cv2.VideoCapture(0)

# 判断摄像头是否成功打开
if not cap_cam.isOpened():
    print("无法打开摄像头，请检查设备是否正常")
else:
    # 获取摄像头实际帧尺寸（解决尺寸不匹配问题）
    frame_width = int(cap_cam.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap_cam.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = 20.0  # 帧率（可根据摄像头性能调整）

    # 定义编码器（mp4格式）
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    # 创建VideoWriter对象（使用摄像头实际尺寸）
    out = cv2.VideoWriter('output.mp4', fourcc, fps, (frame_width, frame_height))

    while True:
        ret, frame = cap_cam.read()
        if not ret:
            print("无法获取摄像头帧，退出录制")
            break
        # 写入帧到视频文件
        out.write(frame)
        # 显示摄像头画面
        cv2.imshow('Camera', frame)
        # 按'q'键停止录制
        if cv2.waitKey(1) == ord('q'):
          
            break

    # 释放资源
    cap_cam.release()
    out.release()
    cv2.destroyAllWindows()  # 关闭摄像头显示窗口