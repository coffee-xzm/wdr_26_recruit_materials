import cv2
import numpy as np
import matplotlib.pyplot as plt

# 读取图像（以灰度图为例）
img = cv2.imread("test_image.png", 0)
# 定义结构元素
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
# 顶帽操作：提取亮的小区域
tophat = cv2.morphologyEx(img, cv2.MORPH_TOPHAT, kernel)
# 黑帽操作：提取暗的小区域
blackhat = cv2.morphologyEx(img, cv2.MORPH_BLACKHAT, kernel)

# 显示结果
cv2.imshow('原始图像', img)
cv2.imshow('礼帽操作（亮区域）', tophat)
cv2.imshow('黑帽操作（暗区域）', blackhat)
cv2.waitKey(0)
cv2.destroyAllWindows()
