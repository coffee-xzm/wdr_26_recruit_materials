import cv2
import numpy as np

# 1. 读取图像并预处理
img = cv2.imread("test_image.jpg")  # 读取彩色图（BGR格式）
if img is None:
    raise ValueError("无法读取图像，请检查路径是否正确")

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # 转为灰度图（角点检测需灰度图输入）
gray = np.float32(gray)  # Harris检测要求输入为float32类型


# 2. Harris角点检测
# 参数说明：
# - gray: 灰度图（float32类型）
# - blockSize: 角点检测的邻域大小（如2表示2x2邻域）
# - ksize: Sobel算子的核大小（如3表示3x3）
# - k: 响应函数中的参数（通常取0.04~0.06）
dst = cv2.cornerHarris(gray, blockSize=2, ksize=3, k=0.04)

# 膨胀操作（可选，让角点标记更明显）
dst = cv2.dilate(dst, None)

# 阈值处理：响应值大于最大值1%的视为角点，用红色标记（BGR格式：[0,0,255]）
img[dst > 0.01 * dst.max()] = [0, 0, 255]


# 3. Shi-Tomasi角点检测（另起一张图，避免与Harris结果重叠）
img_shi = img.copy()  # 复制原图，单独显示Shi-Tomasi结果
# 参数说明：
# - gray: 灰度图（uint8类型）
# - maxCorners: 最大角点数量（如100，超过则返回响应最强的100个）
# - qualityLevel: 角点质量阈值（小于1.0，只有响应值 > 质量阈值*最大响应值的才保留）
# - minDistance: 角点间最小距离（避免密集标注）
corners = cv2.goodFeaturesToTrack(gray.astype(np.uint8), maxCorners=100, qualityLevel=0.01, minDistance=10)

if corners is not None:  # 防止无角点时报错
    corners = np.uint8(corners)  # 转换为整数坐标（uint8更安全）
    # 用绿色圆圈标记角点（半径3，线宽-1表示填充）
    for i in corners:
        x, y = i.ravel()  # 展开坐标
        cv2.circle(img_shi, (x, y), 3, (0, 255, 0), -1)


# 4. 显示结果
cv2.namedWindow("Harris Corners", cv2.WINDOW_NORMAL)
cv2.namedWindow("Shi-Tomasi Corners", cv2.WINDOW_NORMAL)

cv2.imshow("Harris Corners", img)
cv2.imshow("Shi-Tomasi Corners", img_shi)

cv2.waitKey(0)  # 按任意键退出
cv2.destroyAllWindows()