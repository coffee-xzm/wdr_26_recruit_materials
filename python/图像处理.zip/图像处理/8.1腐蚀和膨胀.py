import cv2
import numpy as np

# 读取二值图像
img = cv2.imread('binary_image.jpg', 0)
# 创建3x3的矩形结构元素
kernel = np.ones((3, 3), np.uint8)
# 进行腐蚀操作，迭代1次
eroded_img = cv2.erode(img, kernel, iterations=1)

cv2.imshow('Original Image', img)
cv2.imshow('Eroded Image', eroded_img)
cv2.waitKey(0)
cv2.destroyAllWindows()


# import cv2
# import numpy as np

# # 读取二值图像
# img = cv2.imread('binary_image.jpg', 0)
# # 创建3x3的矩形结构元素
# kernel = np.ones((3, 3), np.uint8)
# # 进行膨胀操作，迭代1次
# dilated_img = cv2.dilate(img, kernel, iterations=1)

# cv2.imshow('Original Image', img)
# cv2.imshow('Dilated Image', dilated_img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
