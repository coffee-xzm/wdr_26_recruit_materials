import numpy as np
import cv2

# 1. 读取图像：如果需要后续转灰度，先以彩色模式读取（默认参数1，可省略）
img = cv2.imread("D:\\111.png")  # 读取为BGR三通道彩色图
# 若确认原图是灰度图，也可直接读为灰度图：img = cv2.imread("D:\\111.png", 0)

# 2. 显示原图（可选）
cv2.imshow('img', img)
cv2.waitKey(0)  # 等待按键输入，否则窗口会一闪而过

# 3. 保存原图（可选）
cv2.imwrite("D:\\222.png", img)

# 4. 转为灰度图（仅当原图是彩色图时需要）
# 若第一步已读为灰度图，可跳过此步
gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# 5. 二值化处理：定义阈值类型（如THRESH_BINARY），修正maxval为255（常规值）
ret, binary_img = cv2.threshold(gray_img, 100, 255, cv2.THRESH_BINARY)

# 6. 显示二值化结果（可选）
cv2.imshow('binary_img', binary_img)
cv2.waitKey(0)
cv2.destroyAllWindows()  # 关闭所有窗口