import cv2
import numpy as np
# 读取图像并预处理（以轮廓检测为例）
img = cv2.imread('D://111.png')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
ret, thresh = cv2.threshold(gray, 127, 255, 0)
contours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# 遍历轮廓，绘制两种外接矩形
for cnt in contours:
    # 1. 轴对齐外接矩形
    x, y, w, h = cv2.boundingRect(cnt)
    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)  # 绿色
    
    # 2. 旋转外接矩形
    rect = cv2.minAreaRect(cnt)
    box = cv2.boxPoints(rect)  # 转换为顶点坐标
    box = np.int32(box)  # 转为整数
    cv2.polylines(img, [box], True, (0, 0, 255), 2)  # 红色
cv2.imshow('Bounding Rectangles', img)
cv2.waitKey(0)