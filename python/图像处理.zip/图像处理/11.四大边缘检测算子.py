import cv2
import numpy as np
# 读取图像并转为灰度图（边缘检测通常基于灰度图）
img = cv2.imread("D://111.png")

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# ----------------------
# 1. Sobel算子（检测水平/垂直方向边缘，对噪声较鲁棒）
# 参数：dx=1, dy=0 检测垂直边缘；dx=0, dy=1 检测水平边缘；ksize=3为核大小（奇数）
sobel_x = cv2.Sobel(gray, cv2.CV_64F, dx=1, dy=0, ksize=3)  # 垂直边缘
sobel_y = cv2.Sobel(gray, cv2.CV_64F, dx=0, dy=1, ksize=3)  # 水平边缘
# 转换为uint8类型（解决负数值截断问题）
sobel_x = cv2.convertScaleAbs(sobel_x)
sobel_y = cv2.convertScaleAbs(sobel_y)
# 合并水平和垂直边缘
sobel_combined = cv2.addWeighted(sobel_x, 0.5, sobel_y, 0.5, 0)

# ----------------------
# 2. Canny算子（多阶段边缘检测，抗噪性好，边缘连续）
# 参数：50和150为双阈值（低阈值用于连接边缘，高阈值用于检测强边缘）
canny = cv2.Canny(gray, threshold1=50, threshold2=150)

# ----------------------
# 3. Laplacian算子（二阶导数，检测所有方向边缘，对噪声敏感）
# 通常先高斯模糊降噪，再用Laplacian
blurred = cv2.GaussianBlur(gray, (3, 3), 0)  # 高斯模糊降噪
laplacian = cv2.Laplacian(blurred, cv2.CV_64F, ksize=3)
laplacian = cv2.convertScaleAbs(laplacian)  # 转换为uint8

# ----------------------
# 4. Prewitt算子（类似Sobel，使用平均权重，对噪声较敏感）
# 手动定义Prewitt核（水平和垂直方向）
prewitt_x = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]], dtype=np.float32)  # 垂直边缘核
prewitt_y = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]], dtype=np.float32)  # 水平边缘核
# 卷积计算
prewitt_x_edge = cv2.filter2D(gray, cv2.CV_64F, prewitt_x)
prewitt_y_edge = cv2.filter2D(gray, cv2.CV_64F, prewitt_y)
# 转换为uint8并合并
prewitt_x_edge = cv2.convertScaleAbs(prewitt_x_edge)
prewitt_y_edge = cv2.convertScaleAbs(prewitt_y_edge)
prewitt_combined = cv2.addWeighted(prewitt_x_edge, 0.5, prewitt_y_edge, 0.5, 0)

# ----------------------
# 显示结果
cv2.namedWindow("原图", cv2.WINDOW_NORMAL)
cv2.namedWindow("Sobel边缘", cv2.WINDOW_NORMAL)
cv2.namedWindow("Canny边缘", cv2.WINDOW_NORMAL)
cv2.namedWindow("Laplacian边缘", cv2.WINDOW_NORMAL)
cv2.namedWindow("Prewitt边缘", cv2.WINDOW_NORMAL)

cv2.imshow("原图", img)
cv2.imshow("Sobel边缘", sobel_combined)
cv2.imshow("Canny边缘", canny)
cv2.imshow("Laplacian边缘", laplacian)
cv2.imshow("Prewitt边缘", prewitt_combined)

cv2.waitKey(0)  # 按任意键退出
cv2.destroyAllWindows()