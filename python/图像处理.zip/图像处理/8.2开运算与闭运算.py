
import cv2
import numpy as np
img = cv2.imread("D://111.png", 0) 
kernel = np.ones((3, 3), np.uint8)  # 3x3矩形结构元素

# 1. 开运算：去除小噪声
opening = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

# 2. 闭运算：填充小孔洞
closing = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)

# 3. 显示结果
cv2.imshow("Original", img)
cv2.imshow("Opening (去噪声)", opening)
cv2.imshow("Closing (填孔洞)", closing)
cv2.waitKey(0)
cv2.destroyAllWindows()
